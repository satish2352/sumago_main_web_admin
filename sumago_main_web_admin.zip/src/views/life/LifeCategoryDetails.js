import React, { useEffect, useState } from 'react';
import {
  Typography,
  TextField,
  Button,
  Grid,
  Input,
  FormControl,
  FormLabel,
  TableContainer,
  Paper,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  MenuItem,
} from '@mui/material';
import PageContainer from 'src/components/container/PageContainer';
import DashboardCard from '../../components/shared/DashboardCard';
import axios from 'axios';
import IconButton from '@mui/material/IconButton';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import { useNavigate } from 'react-router';

const LifeCategoryDetails = () => {
  const [show, setShow] = useState(true);
  const [category, setCategory] = useState('');
  const [img, setImg] = useState(null);
  const [errors, setErrors] = useState({});
  const [data, setData] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [categories, setCategories] = useState([]);
  const navigate = useNavigate();
  useEffect(() => {
    axios
      .get('/life_category/find')
      .then((result) => {
        // Assuming result.data contains an array of category objects like [{ id: 1, name: 'Category 1' }, ...]
        setCategories(result.data);
        console.log(result.data)
      })
      .catch((err) => {
        if (err?.response?.status === 401) {
          navigate('/auth/login');
        }
        console.log('Error fetching categories:', err);
      });
  }, []);
  useEffect(() => {
    axios
      .get('/life_category_details/find_all')
      .then((result) => {
        setData(result.data);
      })
      .catch((err) => {
        if (err?.response?.status === 401) {
          navigate('/auth/login');
        }
        console.log('err', err);
      });
  }, [show]);

  const onClick = () => {
    setShow(true);
    setCategory('');
    setImg(null);
    setErrors({});
    setEditingId(null);
  };
  const onClick1 = () => {
    setShow(false);
  };

  const validateForm = () => {
    let errors = {};
    let isValid = true;

    if (!category.trim()) {
      errors.category = 'Category is required';
      isValid = false;
    }

    if (!img && !editingId) {
      errors.img = 'Image is required';
      isValid = false;
    }

    setErrors(errors);
    return isValid;
  };

  const SubmitForm = (e) => {
    e.preventDefault();
    if (validateForm()) {
      const formData = new FormData();
      formData.append('category', category);
      if (img) {
        formData.append('img', img);
      }

      if (editingId) {
        axios
          .put(`life_category_details/update/${editingId}`, formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
          })
          .then((resp) => {
            console.log('resp', resp);
            alert('Category updated successfully');
            setShow(true);
            setEditingId(null);
          })
          .catch((err) => {
            if (err?.response?.status === 401) {
              navigate('/auth/login');
            }
            console.log('err', err);
          });
      } else {
        axios
          .post('life_category_details/create', formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
          })
          .then((resp) => {
            console.log('resp', resp);
            alert('Form submitted successfully');
            setShow(true);
          })
          .catch((err) => {
            if (err?.response?.status === 401) {
              navigate('/auth/login');
            }
            console.log('err', err);
          });
      }
      setCategory('');
      setImg(null);
      setErrors({});
    }
  };

  const handleEdit = (item) => {
    setCategory(item.category);
    setEditingId(item.id);
    setShow(false);
  };

  const handleDelete = (life_category_details) => {
    console.log('life_category_details', life_category_details);
    axios
      .delete(`life_category_details/delete/${life_category_details}`)
      .then((response) => {
        console.log('Life category details deleted successfully');
        axios
          .get('/life_category_details/find_all')
          .then((result) => {
            setData(result.data);
          })
          .catch((err) => {
            if (err?.response?.status === 401) {
              navigate('/auth/login');
            }
            console.log('err', err);
          });
      })
      .catch((error) => {
        if (error?.response?.status === 401) {
          navigate('/auth/login');
        }
        console.error('Error deleting life_category_details:', error);
      });
  };

  return (
    <PageContainer title="Life Category Details" description="this is Sample page">
      <DashboardCard
        title="Life Category Details"
        buttonName={show ? 'Add Life Category Details' : 'View Life Category Details'}
        onClick={show ? onClick1 : onClick}
      >
        {show ? (
          <TableContainer component={Paper}>
            <Table stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell style={{ fontWeight: 'bold', fontSize: '1rem' }}>Category</TableCell>
                  <TableCell style={{ fontWeight: 'bold', fontSize: '1rem' }}>Profile Image</TableCell>
                  <TableCell style={{ fontWeight: 'bold', fontSize: '1rem' }}>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data.length === 0 ? (
                  <div style={{ marginLeft: '10px', color: 'red' }}>
                    <h3>No data found</h3>
                  </div>
                ) : (
                  data.map((item, id) => {
                    return (
                      <TableRow key={id}>
                        <TableCell>{item?.category}</TableCell>
                        <TableCell>
                          <img src={item?.img} alt={item?.category} style={{ width: '50px', height: '50px' }} />
                        </TableCell>
                        <TableCell>
                          <IconButton
                            aria-label="edit"
                            style={{ color: 'blue' }}
                            onClick={() => handleEdit(item)}
                          >
                            <EditIcon />
                          </IconButton>
                          <IconButton
                            aria-label="delete"
                            style={{ color: 'red' }}
                            onClick={() => handleDelete(item?.id)}
                          >
                            <DeleteIcon />
                          </IconButton>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </TableContainer>
        ) : (
          <form onSubmit={SubmitForm}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  select
                  fullWidth
                  label="Category"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  variant="outlined"
                >
                  {categories.map((cat) => (
                    <MenuItem key={cat.id} value={cat.category}>
                      {cat.category} {/* Display the category name here */}
                    </MenuItem>
                  ))}
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <div>
                  <FormLabel style={{ marginBottom: '10px' }}>File Upload</FormLabel>
                  <Input
                    type="file"
                    onChange={(e) => setImg(e.target.files[0])}
                    fullWidth
                    style={{ marginTop: '10px' }}
                  />
                  {errors.img && (
                    <span className="error" style={{ color: 'red' }}>
                      {errors.img}
                    </span>
                  )}
                </div>
              </Grid>
              <Grid item xs={12}>
                <Button variant="contained" type="submit" color="primary">
                  {editingId ? 'Update' : 'Submit'}
                </Button>
              </Grid>
            </Grid>
          </form>
        )}
      </DashboardCard>
    </PageContainer>
  );
};

export default LifeCategoryDetails;
